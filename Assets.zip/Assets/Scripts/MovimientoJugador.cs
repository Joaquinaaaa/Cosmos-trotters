using UnityEngine;

public class MovimientoJugador : MonoBehaviour
{
    [SerializeField] private float speed = 3f;

    private Rigidbody2D PlayerRb;
    private Vector2 moveInput;

    void Start()
    {
        PlayerRb = GetComponent<Rigidbody2D>();

    }
    
    void Update()
    {
            float moveX = Input.GetAxisRaw("Horizontal");
            float moveY = Input.GetAxisRaw("Vertical");
            moveInput = new Vector2(moveX, moveY).normalized;

    }

    private void FixedUpdate()
    {
        //Físicas
        PlayerRb.MovePosition(PlayerRb.position + moveInput * speed * Time.fixedDeltaTime);
    }

}
